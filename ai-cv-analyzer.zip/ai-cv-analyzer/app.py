"""
app.py
Flask web application: upload a CV, analyze it with Claude, download a PDF report.
"""

import os
import uuid
from dotenv import load_dotenv
from flask import Flask, render_template, request, send_file, jsonify

from modules.extractor import extract_text, UnsupportedFileTypeError
from modules.analyzer import analyze_cv, AnalysisError
from modules.report import generate_pdf_report

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
REPORT_DIR = os.path.join(BASE_DIR, "reports")
ALLOWED_EXTENSIONS = {".pdf", ".docx"}
MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH


def _is_allowed(filename: str) -> bool:
    ext = os.path.splitext(filename)[1].lower()
    return ext in ALLOWED_EXTENSIONS


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    if "cv_file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400

    file = request.files["cv_file"]

    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not _is_allowed(file.filename):
        return jsonify({"error": "Only PDF and DOCX files are supported."}), 400

    # Save upload with a unique name to avoid collisions
    job_id = uuid.uuid4().hex
    ext = os.path.splitext(file.filename)[1].lower()
    saved_path = os.path.join(UPLOAD_DIR, f"{job_id}{ext}")
    file.save(saved_path)

    try:
        cv_text = extract_text(saved_path)
        analysis = analyze_cv(cv_text)

        report_path = os.path.join(REPORT_DIR, f"{job_id}_report.pdf")
        generate_pdf_report(analysis, report_path, cv_filename=file.filename)

        return jsonify(
            {
                "analysis": analysis,
                "report_id": job_id,
            }
        )

    except UnsupportedFileTypeError as e:
        return jsonify({"error": str(e)}), 400
    except AnalysisError as e:
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        return jsonify({"error": f"Unexpected error: {e}"}), 500
    finally:
        # Clean up the uploaded source file; keep only the generated report
        if os.path.exists(saved_path):
            os.remove(saved_path)


@app.route("/download/<report_id>")
def download_report(report_id):
    # Basic sanity check on the id to avoid path traversal
    safe_id = "".join(c for c in report_id if c.isalnum())
    report_path = os.path.join(REPORT_DIR, f"{safe_id}_report.pdf")

    if not os.path.exists(report_path):
        return jsonify({"error": "Report not found."}), 404

    return send_file(report_path, as_attachment=True, download_name="CV_Analysis_Report.pdf")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
