# AI CV Analyzer

An AI-powered web app that analyzes your CV/resume, tells you what's missing or
weak, and generates a downloadable PDF report — powered by the Claude API.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Flask](https://img.shields.io/badge/Flask-3.0-black)
![License](https://img.shields.io/badge/license-MIT-green)

## Features

- **File upload** — drag-and-drop or click-to-browse for PDF/DOCX resumes
- **AI-powered analysis** — uses the Claude API to identify strengths, weak
  points, missing sections, and gives an overall score out of 100
- **PDF report generation** — a clean, shareable PDF report built with
  ReportLab
- **Simple, responsive UI** — no frontend framework required

## Tech Stack

| Layer          | Technology                          |
|----------------|--------------------------------------|
| Backend        | Python, Flask                        |
| AI             | Anthropic Claude API                 |
| File parsing   | `pdfplumber`, `python-docx`          |
| PDF generation | `reportlab`                          |
| Frontend       | Vanilla HTML / CSS / JavaScript      |

## What I learned building this

- Handling file uploads securely in Flask (extension validation, size limits,
  unique filenames, cleanup after processing)
- Extracting text from different document formats (PDF vs DOCX)
- Designing a prompt that reliably returns structured JSON from an LLM
- Calling a third-party API (Anthropic's Claude API) from a backend service
  and handling API errors gracefully
- Generating a formatted PDF document programmatically from dynamic data
- Building a small full-stack feature end-to-end: upload → process → AI call
  → generate file → download

## Project Structure

```
ai-cv-analyzer/
├── app.py                  # Flask app & routes
├── modules/
│   ├── extractor.py        # PDF/DOCX text extraction
│   ├── analyzer.py         # Claude API call + prompt
│   └── report.py           # PDF report generation
├── templates/
│   └── index.html          # Upload page
├── static/
│   ├── style.css
│   └── script.js
├── uploads/                # Temporary storage (cleared after each request)
├── reports/                # Generated PDF reports
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

1. **Clone the repo**
   ```bash
   git clone https://github.com/YOUR_USERNAME/ai-cv-analyzer.git
   cd ai-cv-analyzer
   ```

2. **Create a virtual environment and install dependencies**
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Add your API key**
   ```bash
   cp .env.example .env
   ```
   Then open `.env` and paste your key from
   [console.anthropic.com](https://console.anthropic.com/):
   ```
   ANTHROPIC_API_KEY=your_api_key_here
   ```

4. **Run the app**
   ```bash
   python app.py
   ```
   Open [http://localhost:5000](http://localhost:5000) in your browser.

## How it works

1. User uploads a CV (PDF or DOCX) through the web UI.
2. Flask saves the file temporarily and extracts its raw text
   (`modules/extractor.py`).
3. The text is sent to Claude with a prompt asking for structured JSON
   feedback: overall score, strengths, missing points, section-by-section
   feedback, and actionable suggestions (`modules/analyzer.py`).
4. The JSON result is rendered in the browser **and** turned into a
   downloadable PDF report (`modules/report.py`).
5. The temporary uploaded file is deleted; only the generated report is kept.

## Possible Improvements

- User accounts + history of past analyses
- Support for `.txt` and image-based (OCR) resumes
- Multi-language analysis (e.g. Turkish CVs)
- Compare CV against a specific job description for tailored feedback
- Deploy to Render / Railway / Fly.io with a live demo link

## License

MIT — feel free to use this project as a learning reference or portfolio
piece.
