"""
report.py
Generates a polished PDF report from the structured AI analysis result.
"""

from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    ListFlowable,
    ListItem,
    Table,
    TableStyle,
)


def _build_styles():
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TitleBig",
            fontSize=22,
            leading=26,
            textColor=colors.HexColor("#1f2937"),
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Subtitle",
            fontSize=11,
            textColor=colors.HexColor("#6b7280"),
            spaceAfter=20,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SectionHeading",
            fontSize=14,
            textColor=colors.HexColor("#111827"),
            spaceBefore=16,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Body",
            fontSize=10.5,
            leading=15,
            textColor=colors.HexColor("#1f2937"),
        )
    )
    return styles


def generate_pdf_report(analysis: dict, output_path: str, cv_filename: str = "CV") -> str:
    """
    Build a PDF report from the analysis dictionary.

    Args:
        analysis: The structured dict returned by analyzer.analyze_cv().
        output_path: Where to save the generated PDF.
        cv_filename: Original CV filename, shown in the report header.

    Returns:
        The output_path (for convenience/chaining).
    """
    styles = _build_styles()
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
    )

    story = []

    # Header
    story.append(Paragraph("CV Analysis Report", styles["TitleBig"]))
    story.append(
        Paragraph(
            f"Source file: {cv_filename} &nbsp;|&nbsp; "
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            styles["Subtitle"],
        )
    )

    # Score box
    score = analysis.get("overall_score", "N/A")
    score_table = Table(
        [[f"Overall Score: {score}/100"]],
        colWidths=[17 * cm],
    )
    score_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eef2ff")),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#3730a3")),
                ("FONTSIZE", (0, 0), (-1, -1), 14),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    story.append(score_table)
    story.append(Spacer(1, 12))

    # Summary
    story.append(Paragraph("Summary", styles["SectionHeading"]))
    story.append(Paragraph(analysis.get("summary", ""), styles["Body"]))

    # Strengths
    strengths = analysis.get("strengths", [])
    if strengths:
        story.append(Paragraph("Strengths", styles["SectionHeading"]))
        story.append(
            ListFlowable(
                [ListItem(Paragraph(s, styles["Body"])) for s in strengths],
                bulletType="bullet",
            )
        )

    # Missing / weak points
    weak_points = analysis.get("missing_or_weak_points", [])
    if weak_points:
        story.append(Paragraph("Missing or Weak Points", styles["SectionHeading"]))
        story.append(
            ListFlowable(
                [ListItem(Paragraph(w, styles["Body"])) for w in weak_points],
                bulletType="bullet",
            )
        )

    # Section-by-section feedback
    section_feedback = analysis.get("section_feedback", [])
    if section_feedback:
        story.append(Paragraph("Section-by-Section Feedback", styles["SectionHeading"]))
        for item in section_feedback:
            section_name = item.get("section", "Section")
            feedback_text = item.get("feedback", "")
            story.append(Paragraph(f"<b>{section_name}</b>", styles["Body"]))
            story.append(Paragraph(feedback_text, styles["Body"]))
            story.append(Spacer(1, 6))

    # Actionable suggestions
    suggestions = analysis.get("actionable_suggestions", [])
    if suggestions:
        story.append(Paragraph("Actionable Suggestions", styles["SectionHeading"]))
        story.append(
            ListFlowable(
                [ListItem(Paragraph(s, styles["Body"])) for s in suggestions],
                bulletType="bullet",
            )
        )

    doc.build(story)
    return output_path
