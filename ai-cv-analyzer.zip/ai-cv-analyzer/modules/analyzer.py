"""
analyzer.py
Sends extracted CV text to the Claude API and gets back a structured analysis:
overall score, strengths, weaknesses/missing points, and section-by-section feedback.
"""

import os
import json
import anthropic

MODEL_NAME = "claude-sonnet-5"

SYSTEM_PROMPT = """You are an expert technical recruiter and career coach with 15 years
of experience reviewing resumes/CVs for the tech industry. You give direct, honest,
and constructive feedback. You always respond with STRICT JSON only — no markdown,
no code fences, no commentary before or after the JSON object."""

USER_PROMPT_TEMPLATE = """Analyze the following CV text and return your analysis as a
single JSON object with EXACTLY this structure:

{{
  "overall_score": <integer 0-100>,
  "summary": "<2-3 sentence overall impression>",
  "strengths": ["<point 1>", "<point 2>", ...],
  "missing_or_weak_points": ["<point 1>", "<point 2>", ...],
  "section_feedback": [
    {{"section": "<e.g. Experience>", "feedback": "<specific feedback for this section>"}}
  ],
  "actionable_suggestions": ["<concrete suggestion 1>", "<concrete suggestion 2>", ...]
}}

Be specific and reference actual content from the CV where possible. Focus on things
like: missing quantifiable achievements, unclear job descriptions, missing skills
section, poor formatting signals (inferred from text structure), missing keywords for
ATS systems, unclear career narrative, and missing contact/links (portfolio, GitHub,
LinkedIn).

CV TEXT:
---
{cv_text}
---

Return ONLY the JSON object, nothing else."""


class AnalysisError(Exception):
    """Raised when the AI analysis fails or returns invalid data."""
    pass


def analyze_cv(cv_text: str) -> dict:
    """
    Send CV text to Claude and parse the structured JSON response.

    Args:
        cv_text: The raw text extracted from the CV.

    Returns:
        A dictionary matching the structure described in USER_PROMPT_TEMPLATE.

    Raises:
        AnalysisError: If the API call fails or the response isn't valid JSON.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise AnalysisError(
            "ANTHROPIC_API_KEY environment variable is not set. "
            "Copy .env.example to .env and add your key."
        )

    client = anthropic.Anthropic(api_key=api_key)

    # Guard against extremely short/empty extraction (e.g. scanned/image-only PDFs)
    if len(cv_text.strip()) < 50:
        raise AnalysisError(
            "Very little text could be extracted from this file. "
            "If this is a scanned/image-based PDF, please upload a text-based CV instead."
        )

    try:
        response = client.messages.create(
            model=MODEL_NAME,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=[
                {
                    "role": "user",
                    "content": USER_PROMPT_TEMPLATE.format(cv_text=cv_text[:15000]),
                }
            ],
        )
    except anthropic.APIError as e:
        raise AnalysisError(f"Claude API request failed: {e}")

    raw_text = "".join(
        block.text for block in response.content if block.type == "text"
    ).strip()

    # Defensive cleanup in case the model wraps the JSON in code fences anyway
    if raw_text.startswith("```"):
        raw_text = raw_text.strip("`")
        if raw_text.lower().startswith("json"):
            raw_text = raw_text[4:].strip()

    try:
        result = json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise AnalysisError(f"Could not parse AI response as JSON: {e}\nRaw: {raw_text[:500]}")

    return result
