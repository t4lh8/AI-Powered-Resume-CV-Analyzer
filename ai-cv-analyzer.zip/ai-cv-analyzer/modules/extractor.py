"""
extractor.py
Extracts raw text content from an uploaded CV file (PDF or DOCX).
"""

import os
import pdfplumber
import docx


class UnsupportedFileTypeError(Exception):
    """Raised when the uploaded file type is not supported."""
    pass


def extract_text(file_path: str) -> str:
    """
    Extract plain text from a PDF or DOCX file.

    Args:
        file_path: Absolute path to the uploaded file.

    Returns:
        Extracted text as a single string.

    Raises:
        UnsupportedFileTypeError: If the file extension is not .pdf or .docx
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        return _extract_from_pdf(file_path)
    elif ext == ".docx":
        return _extract_from_docx(file_path)
    else:
        raise UnsupportedFileTypeError(
            f"Unsupported file type: '{ext}'. Please upload a PDF or DOCX file."
        )


def _extract_from_pdf(file_path: str) -> str:
    text_chunks = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_chunks.append(page_text)
    return "\n".join(text_chunks).strip()


def _extract_from_docx(file_path: str) -> str:
    document = docx.Document(file_path)
    paragraphs = [p.text for p in document.paragraphs if p.text.strip()]
    return "\n".join(paragraphs).strip()
