const form = document.getElementById("upload-form");
const dropLabel = document.getElementById("drop-label");
const fileInput = document.getElementById("cv_file");
const fileNameSpan = document.getElementById("file-name");
const dropText = document.getElementById("drop-text");
const analyzeBtn = document.getElementById("analyze-btn");

const loadingEl = document.getElementById("loading");
const errorEl = document.getElementById("error");
const resultsEl = document.getElementById("results");

// Show selected filename
fileInput.addEventListener("change", () => {
  if (fileInput.files.length > 0) {
    fileNameSpan.textContent = fileInput.files[0].name;
    dropText.textContent = "Selected:";
  }
});

// Drag & drop support
["dragenter", "dragover"].forEach((evt) =>
  dropLabel.addEventListener(evt, (e) => {
    e.preventDefault();
    dropLabel.classList.add("dragover");
  })
);

["dragleave", "drop"].forEach((evt) =>
  dropLabel.addEventListener(evt, (e) => {
    e.preventDefault();
    dropLabel.classList.remove("dragover");
  })
);

dropLabel.addEventListener("drop", (e) => {
  const dropped = e.dataTransfer.files;
  if (dropped.length > 0) {
    fileInput.files = dropped;
    fileNameSpan.textContent = dropped[0].name;
    dropText.textContent = "Selected:";
  }
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  if (!fileInput.files.length) {
    showError("Please choose a PDF or DOCX file first.");
    return;
  }

  resetUI();
  loadingEl.classList.remove("hidden");
  analyzeBtn.disabled = true;

  const formData = new FormData();
  formData.append("cv_file", fileInput.files[0]);

  try {
    const response = await fetch("/analyze", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Something went wrong.");
    }

    renderResults(data.analysis, data.report_id);
  } catch (err) {
    showError(err.message);
  } finally {
    loadingEl.classList.add("hidden");
    analyzeBtn.disabled = false;
  }
});

function resetUI() {
  errorEl.classList.add("hidden");
  resultsEl.classList.add("hidden");
}

function showError(message) {
  errorEl.textContent = message;
  errorEl.classList.remove("hidden");
}

function renderResults(analysis, reportId) {
  document.getElementById("score-value").textContent = analysis.overall_score ?? "--";
  document.getElementById("summary-text").textContent = analysis.summary ?? "";

  fillList("strengths-list", analysis.strengths || []);
  fillList("weak-points-list", analysis.missing_or_weak_points || []);
  fillList("suggestions-list", analysis.actionable_suggestions || []);

  const downloadBtn = document.getElementById("download-btn");
  downloadBtn.href = `/download/${reportId}`;

  resultsEl.classList.remove("hidden");
  resultsEl.scrollIntoView({ behavior: "smooth" });
}

function fillList(elementId, items) {
  const ul = document.getElementById(elementId);
  ul.innerHTML = "";
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    ul.appendChild(li);
  });
}
